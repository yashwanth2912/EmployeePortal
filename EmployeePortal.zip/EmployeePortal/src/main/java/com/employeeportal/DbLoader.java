package com.employeeportal;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class DbLoader {
 
    private EmployeeRepository repo;
     
    public DbLoader(EmployeeRepository repo) {
        this.repo = repo;
    }
 
    @Bean
    public CommandLineRunner initializeDatabase() {
        return args -> {
            Employee employee1 = new Employee("yashwanth@tcs.com", "yash123", Role.HR);
            Employee employee2 = new Employee("y.m@tcs.com", "yash567", Role.HR);
            Employee employee3 = new Employee("bhaskar.p@tcs.com", "bpulla32", Role.EMPLOYEE);
            Employee employee4 = new Employee("dileep@tcs.com", "dileep324", Role.EMPLOYEE);
             
            repo.saveAll(List.of(employee1, employee2,employee3,employee4));
             
            System.out.println("Database initialized");
        };
    }
}
