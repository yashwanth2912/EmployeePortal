package com.employeeportal;

public enum Role {

	EMPLOYEE,HR
}
