package com.employeeportal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
public class MainController {

	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}
	
	@GetMapping("/hr/login")
	public String viewHrLoginPage() {
		return "hr/HrLogin";
	}
	
	@GetMapping("/employee/login")
	public String viewEmployeeLoginPage() {
		return "employee/employeelogin";
	}
	
	@GetMapping("/hr/home")
	public String viewHrHomePage() {
		return "hr/hrhome";
	}
	
	@GetMapping("/employee/home")
	public String viewEmployeeHomePage() {
		return "employee/employeehome";
	}
	
}
